<footer style="width: 100%;float: left;">
	<div class="agileits-footer-bottom text-center" style="padding-top: 20px;">
		<div class="container">
			<div class="w3-footer-logo">
				<h1><a href="/"><span>闲置</span>购</a></h1>
			</div>
			<div class="w3-footer-social-icons">
			</div>
			<div class="copyrights">
				<p> © 2017 Resale. All Rights Reserved</p>
			</div>
			<div class="clearfix"></div>
		</div>
	</div>
</footer>