<?php
namespace backend\models;
use Yii;

class SiteUser extends yii\db\ActiveRecord
{

}
?>